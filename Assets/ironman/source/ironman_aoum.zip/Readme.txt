This archive is provided for nonprofit use only.

Fbx folder contains animations.

Textures:
256 npc difference normal & specualr maps
512 team-up npc difference & normal maps, max resolution of all specualr maps and transparency masks
1024 player character difference & normal maps


